package br.unip.ads.pim4.application;

public abstract class AbstractAppService {

}
